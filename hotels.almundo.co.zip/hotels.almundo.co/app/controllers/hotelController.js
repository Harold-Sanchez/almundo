(function() {
    'use strict';

    angular
        .module('app')
        .controller('hotelController', Controller);

    Controller.$inject = ['$scope', '$rootScope', 'hotelService', '$state', '$stateParams'];

    function Controller($scope, $rootScope, hotelService, $state, $stateParams) {
        //$scope.search=[];
        $scope.hotels = [];
        $rootScope.search ={stars:''};

        $rootScope.search.stars='';


        if ($state.current.name == "hotels") {
            $rootScope.Title = "Hotel Listing";
            hotelService.getHotels().then(function(res) {
                $scope.hotels = res.data;
            }).catch(function(err) {
                console.log(err);
            });

            $scope.deleteHotel = function(id) {
                if (confirm('Are you sure to delete?')) {
                    hotelService.deleteHotel(id).then(function(res) {
                        if (res.data == "deleted") {
                            $state.go("hotels", {}, { reload: true });
                        }
                    }).catch(function(err) {
                        console.log(err);
                    });
                }
            };
        } else if ($state.current.name == "edit") {
            $rootScope.Title = "Edit Hotel";
            var id = $stateParams.id;
            hotelService.getHotel(id).then(function(res) {
                $scope.hotel = res.data;
            }).catch(function(err) {
                console.log(err);
            });

            $scope.saveData = function(hotel) {
                if ($scope.hotelForm.$valid) {
                   hotelService.updateHotel(hotel).then(function(res) {
                        if (res.data == "updated") {
                            $state.go("hotels");
                        }
                    }).catch(function(err) {
                        console.log(err);
                    });
                }
            };
        } else if ($state.current.name == "create") {
            $rootScope.Title = "Create Hotel";
            $scope.saveData = function(hotel) {
                $scope.IsSubmit = true;
                if ($scope.hotelForm.$valid) {
                    hotelService.createHotel(hotel).then(function(res) {
                        if (res.data == "created") {
                            $state.go("hotels");
                        }
                    }).catch(function(err) {
                        console.log(err);
                    });
                }
            };
        }
    }
})();