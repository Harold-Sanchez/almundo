(function() {
    'use strict';

    angular.module('app', [
        "ui.router"
    ])
        .config(function($stateProvider, $urlRouterProvider) {
            $urlRouterProvider.otherwise("/");

            $stateProvider.state("hotels", {
                url: "/",
                templateUrl: "/views/hotel/index.html",
                controller: "hotelController"
            }).state("create", {
                url: "/create",
                templateUrl: "/views/hotel/create.html",
                controller: "hotelController"
            }).state("edit", {
                url: "/edit/:id",
                templateUrl: "/views/hotel/create.html",
                controller: "hotelController"
            }).state("details", {
                url: "/details/:id",
                templateUrl: "/views/hotel/details.html",
                controller: "hotelController"
            });
        })
        .constant("globalConfig", {
            apiAddress: 'http://localhost:3000/api'
        });
})();