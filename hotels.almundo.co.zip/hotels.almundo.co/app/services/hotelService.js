(function() {
    'use strict';

    angular
        .module('app')
        .factory('hotelService', Service);

    Service.$inject = ['$http', 'globalConfig'];

    function Service($http, globalConfig) {
        var url = "";
        return {
            getHotels: function() {
                url = globalConfig.apiAddress + "/hotel";
                return $http.get(url);
            },
            getHotel: function(id) {
                url = globalConfig.apiAddress + "/hotel/" + id;
                return $http.get(url);
            },
            createHotel: function(hotel) {
                url = globalConfig.apiAddress + "/hotel";
                return $http.post(url, hotel);
            },
            updateHotel: function(hotel) {
                url = globalConfig.apiAddress + "/hotel/" + hotel._id;
                return $http.put(url, hotel);
            },
            deleteHotel: function(id) {
                url = globalConfig.apiAddress + "/hotel/" + id;
                return $http.delete(url);
            }
        };
    }
})();