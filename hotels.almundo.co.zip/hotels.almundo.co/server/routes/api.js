var express = require('express'),
    router = express.Router();

//routes for hotel api
router.use("/hotel", require("../controllers/hotel.api"));

//add here other api routes

module.exports = router;