var mongoose = require('mongoose');
var connection = mongoose.connect('mongodb://localhost/hotels_db');

module.exports = connection;