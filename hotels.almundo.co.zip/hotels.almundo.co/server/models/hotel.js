var mongoose = require("mongoose"),
    Schema = mongoose.Schema,
    objectId = mongoose.Schema.ObjectId;

var hotelSchema = new Schema({
    _id: { type: objectId, auto: true },
    name: { type: String, required: true },
    stars: { type: Number, required: true },
    price: { type: Number, required: true },
    image: { type: String, required: true },
    amenities: { type: Array, required: true }
}, {
    versionKey: false
});

var hotel = mongoose.model('hotels', hotelSchema);

module.exports = hotel;